/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        forge: {
          black: '#050913',
          ink: '#081120',
          navy: '#0b1830',
          card: '#0d203d',
          line: '#18365f',
          blue: '#10a7ff',
          cyan: '#54d4ff',
        },
      },
      boxShadow: {
        glow: '0 0 32px rgba(16, 167, 255, 0.22)',
        card: '0 18px 50px rgba(0, 0, 0, 0.28)',
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}

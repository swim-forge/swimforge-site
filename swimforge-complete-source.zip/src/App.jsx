import { useState } from 'react'
import {
  Activity,
  ArrowRight,
  ChevronDown,
  Dumbbell,
  Gauge,
  Goal,
  Instagram,
  Medal,
  Send,
  ShieldCheck,
  Sparkles,
  Timer,
  Waves,
  Zap,
} from 'lucide-react'

const STRIPE_ANALYSIS_LINK = "PASTE_ANALYSIS_PAYMENT_LINK_HERE"
const STRIPE_PROGRAM_LINK = "PASTE_PROGRAM_PAYMENT_LINK_HERE"
const STRIPE_BUNDLE_LINK = "PASTE_BUNDLE_PAYMENT_LINK_HERE"

const programs = [
  {
    id: 'stroke-analysis',
    name: 'Stroke Video Analysis',
    price: 45,
    description:
      'Detailed stroke breakdown with corrections, drills, and key performance improvements.',
    button: 'Buy Analysis',
    paymentLink: STRIPE_ANALYSIS_LINK,
  },
  {
    id: 'gym-program',
    name: 'Custom Gym Program',
    price: 45,
    description:
      'A structured strength and power plan tailored to your stroke, events, and training setup.',
    button: 'Buy Program',
    paymentLink: STRIPE_PROGRAM_LINK,
  },
  {
    id: 'performance-bundle',
    name: 'Performance Bundle',
    price: 80,
    description:
      'Complete performance system combining stroke analysis and a custom gym program.',
    button: 'Buy Bundle',
    paymentLink: STRIPE_BUNDLE_LINK,
    featured: true,
  },
]

const competitiveCards = [
  {
    title: 'Stroke-specific strength',
    text: 'Targeted gym work that supports the demands of your main stroke.',
    icon: Dumbbell,
  },
  {
    title: 'Power and speed development',
    text: 'Explosive movement patterns built for starts, turns, and breakout speed.',
    icon: Zap,
  },
  {
    title: 'Race-focused programming',
    text: 'Training choices shaped around events, race skills, and repeatable progress.',
    icon: Medal,
  },
]

const benefits = [
  ['Faster starts and turns', Timer],
  ['Stronger stroke mechanics', Waves],
  ['More explosive speed', Gauge],
  ['Structured progression', Activity],
  ['Reduced injury risk', ShieldCheck],
  ['Better race execution', Goal],
]

const phases = [
  {
    name: 'Foundation',
    text: 'Build control, mobility, and movement quality before loading intensity.',
  },
  {
    name: 'Strength',
    text: 'Develop the force base that supports stronger pulling, kicking, and body position.',
  },
  {
    name: 'Power',
    text: 'Convert strength into explosive starts, turns, and race-speed actions.',
  },
  {
    name: 'Speed',
    text: 'Sharpen execution with high-output work built around performance transfer.',
  },
]

const faqs = [
  [
    'Is this for all strokes?',
    'Yes. Your analysis or program is built around your main stroke, secondary stroke, events, and current race demands.',
  ],
  [
    'Do I need a full gym?',
    'No. SwimForge adapts your plan to the equipment you have access to, from basic bands and dumbbells to a complete gym.',
  ],
  [
    'How long does delivery take?',
    'Your SwimForge system is delivered within 24-48 hours after your athlete profile is submitted.',
  ],
  [
    'What if I have an injury?',
    'Include your injury history in the intake form so your program can be adjusted around limitations and safer training choices.',
  ],
  [
    'What is included in the bundle?',
    'The bundle includes stroke video analysis plus a custom gym program, giving you both technical corrections and a performance plan.',
  ],
]

const initialForm = {
  name: '',
  email: '',
  age: '',
  mainStroke: '',
  secondaryStroke: '',
  mainEvents: '',
  bestTimes: '',
  courseType: 'LCM',
  swimSessions: '',
  gymExperience: '',
  equipment: '',
  goals: '',
  weaknesses: '',
  injuryHistory: '',
}

const getStoredPackage = () => {
  const storedPackageId = window.localStorage.getItem('swimforge_package_id')
  return programs.find((program) => program.id === storedPackageId) || programs[2]
}

function App() {
  const [formData, setFormData] = useState(initialForm)
  const [submitted, setSubmitted] = useState(false)
  const isProfilePage = window.location.pathname === '/profile'
  const purchasedPackage = isProfilePage ? getStoredPackage() : null

  const handleChange = (event) => {
    const { name, value } = event.target
    setFormData((current) => ({ ...current, [name]: value }))
  }

  const handleSubmit = (event) => {
    event.preventDefault()
    setSubmitted(true)
  }

  return (
    <div className="min-h-screen overflow-hidden bg-forge-black text-white">
      <Header isProfilePage={isProfilePage} />
      {isProfilePage ? (
        <main>
          <ProfilePage
            formData={formData}
            onChange={handleChange}
            onSubmit={handleSubmit}
            submitted={submitted}
            purchasedPackage={purchasedPackage}
          />
        </main>
      ) : (
        <main>
          <Hero />
          <CompetitiveSection />
          <PricingSection />
          <HowItWorks />
          <WhatYouGet />
          <ProgramStructure />
          <Faq />
        </main>
      )}
      <Footer />
    </div>
  )
}

function Header({ isProfilePage }) {
  const sectionPath = isProfilePage ? '/' : ''

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-forge-black/86 backdrop-blur-xl">
      <div className="container-shell flex min-h-20 items-center justify-between gap-4">
        <a href="/" className="flex items-center gap-3" aria-label="SwimForge home">
          <span className="grid h-10 w-10 place-items-center rounded-lg border border-forge-blue/45 bg-forge-blue/12 text-forge-cyan shadow-glow">
            <Waves size={22} />
          </span>
          <span className="text-xl font-black tracking-wide">SwimForge</span>
        </a>

        <nav className="hidden items-center gap-8 text-sm font-semibold text-slate-300 md:flex">
          <a className="transition hover:text-forge-cyan" href={`${sectionPath}#programs`}>
            Programs
          </a>
          <a className="transition hover:text-forge-cyan" href={`${sectionPath}#how-it-works`}>
            How It Works
          </a>
          <a className="transition hover:text-forge-cyan" href={`${sectionPath}#benefits`}>
            Benefits
          </a>
          <a className="transition hover:text-forge-cyan" href={`${sectionPath}#faq`}>
            FAQ
          </a>
        </nav>

        <a
          href={`${sectionPath}#programs`}
          className="inline-flex min-h-11 items-center justify-center rounded-md bg-forge-blue px-4 text-sm font-bold text-forge-black shadow-glow transition hover:-translate-y-0.5 hover:bg-forge-cyan"
        >
          Start Your Program
        </a>
      </div>
    </header>
  )
}

function Hero() {
  return (
    <section id="top" className="relative min-h-[calc(100vh-80px)] overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(16,167,255,0.22),transparent_28%),radial-gradient(circle_at_82%_30%,rgba(84,212,255,0.13),transparent_24%),linear-gradient(140deg,#050913_0%,#081120_45%,#0b1830_100%)]" />
      <div className="absolute inset-0 opacity-[0.18] [background-image:linear-gradient(rgba(255,255,255,.12)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.1)_1px,transparent_1px)] [background-size:46px_46px]" />
      <div className="container-shell relative flex min-h-[calc(100vh-80px)] items-center py-16">
        <div className="max-w-3xl">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-forge-blue/35 bg-white/5 px-4 py-2 text-sm font-semibold text-forge-cyan">
            <Sparkles size={16} />
            Build strength. Create speed.
          </div>
          <h1 className="max-w-4xl text-5xl font-black leading-[0.98] tracking-normal text-white sm:text-6xl lg:text-7xl">
            Build Race-Winning Performance
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-300 sm:text-xl">
            Custom swim strength programs built to increase power, speed, and real race
            performance.
          </p>
          <div className="mt-9 flex flex-col gap-3 sm:flex-row">
            <a
              href="#programs"
              className="inline-flex min-h-12 items-center justify-center rounded-md bg-forge-blue px-6 text-base font-bold text-forge-black shadow-glow transition hover:-translate-y-0.5 hover:bg-forge-cyan"
            >
              Start Your Program
              <ArrowRight className="ml-2" size={18} />
            </a>
            <a
              href="#programs"
              className="inline-flex min-h-12 items-center justify-center rounded-md border border-white/18 bg-white/6 px-6 text-base font-bold text-white transition hover:-translate-y-0.5 hover:border-forge-cyan hover:text-forge-cyan"
            >
              View Programs
            </a>
          </div>
          <p className="mt-5 text-sm font-semibold text-slate-400">Delivered within 24-48 hours.</p>
        </div>
      </div>
    </section>
  )
}

function CompetitiveSection() {
  return (
    <section className="section-pad bg-forge-ink">
      <div className="container-shell">
        <div className="max-w-2xl">
          <p className="eyebrow">Built for Competitive Swimmers</p>
          <h2 className="mt-3 text-3xl font-black sm:text-4xl">Training built for the pool.</h2>
          <p className="mt-4 text-lg leading-8 text-slate-300">
            Designed for swimmers who want real race performance - not random gym workouts.
          </p>
        </div>
        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {competitiveCards.map(({ title, text, icon: Icon }) => (
            <article key={title} className="card-surface rounded-lg p-6 transition hover:-translate-y-1 hover:border-forge-blue">
              <Icon className="text-forge-cyan" size={30} />
              <h3 className="mt-5 text-xl font-bold">{title}</h3>
              <p className="mt-3 leading-7 text-slate-300">{text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

function PricingSection() {
  return (
    <section id="programs" className="section-pad bg-forge-black">
      <div className="container-shell">
        <div className="mx-auto max-w-2xl text-center">
          <p className="eyebrow">Programs</p>
          <h2 className="mt-3 text-3xl font-black sm:text-4xl">Choose Your Program</h2>
          <p className="mt-4 leading-7 text-slate-300">
            Checkout opens through Stripe. After payment, you will be redirected to your athlete
            profile.
          </p>
        </div>
        <div className="mt-12 grid items-stretch gap-5 lg:grid-cols-3">
          {programs.map((program) => (
            <ProgramCard key={program.id} program={program} />
          ))}
        </div>
      </div>
    </section>
  )
}

function ProgramCard({ program }) {
  const rememberPackage = () => {
    window.localStorage.setItem('swimforge_package_id', program.id)
  }

  return (
    <article
      className={`relative rounded-lg p-6 transition duration-300 hover:-translate-y-1 ${
        program.featured
          ? 'border-2 border-forge-blue bg-gradient-to-b from-forge-card to-forge-navy shadow-glow lg:scale-[1.03]'
          : 'card-surface'
      }`}
    >
      {program.featured && (
        <div className="mb-5 inline-flex rounded-full bg-forge-blue px-3 py-1 text-xs font-black uppercase tracking-[0.16em] text-forge-black">
          Best Value
        </div>
      )}
      <h3 className="text-2xl font-black">{program.name}</h3>
      <div className="mt-5 flex items-end gap-1">
        <span className="text-5xl font-black text-white">${program.price}</span>
      </div>
      <p className="mt-5 min-h-24 leading-7 text-slate-300">{program.description}</p>
      <a
        href={program.paymentLink}
        onClick={rememberPackage}
        className={`mt-7 inline-flex min-h-12 w-full items-center justify-center rounded-md px-5 font-bold transition ${
          program.featured
            ? 'bg-forge-blue text-forge-black shadow-glow hover:bg-forge-cyan'
            : 'border border-white/16 bg-white/6 text-white hover:border-forge-cyan hover:text-forge-cyan'
        }`}
      >
        {program.button}
      </a>
    </article>
  )
}

function ProfilePage({ formData, onChange, onSubmit, submitted, purchasedPackage }) {
  return (
    <section className="bg-forge-ink py-8 sm:py-10">
      <div className="container-shell">
        <div className="rounded-lg border border-forge-blue/55 bg-forge-blue/10 p-5 shadow-glow sm:p-7">
          <div className="grid gap-5 lg:grid-cols-[1fr_auto] lg:items-center">
            <div>
              <p className="flex items-start gap-3 text-lg font-black leading-7 text-forge-cyan">
                <ShieldCheck className="mt-1 shrink-0" size={22} />
                Payment confirmed. Complete your athlete profile to receive your SwimForge program.
              </p>
              <p className="mt-3 leading-7 text-slate-300">
                Your program will be delivered within 24–48 hours after submission.
              </p>
            </div>
            <div className="rounded-lg border border-forge-blue/35 bg-forge-navy/90 p-4 sm:min-w-64">
              <p className="text-xs font-black uppercase tracking-[0.18em] text-forge-cyan">
                Purchased
              </p>
              <p className="mt-2 text-xl font-black text-white">{purchasedPackage.name}</p>
              <p className="mt-1 text-3xl font-black text-forge-cyan">${purchasedPackage.price}</p>
            </div>
          </div>
        </div>
      </div>
      <IntakeForm
        formData={formData}
        onChange={onChange}
        onSubmit={onSubmit}
        submitted={submitted}
      />
    </section>
  )
}

function IntakeForm({ formData, onChange, onSubmit, submitted }) {
  return (
    <section id="athlete-profile" className="bg-forge-black py-12 sm:py-16 lg:py-20">
      <div className="container-shell">
        <div className="grid gap-8 lg:grid-cols-[0.8fr_1.2fr] lg:gap-12">
          <div>
            <p className="eyebrow">Athlete Profile</p>
            <h2 className="mt-3 text-3xl font-black sm:text-4xl">Build the plan around you.</h2>
            <p className="mt-4 leading-8 text-slate-300">
              Share your events, training setup, goals, and constraints so SwimForge can shape the
              right performance system for your race demands.
            </p>
          </div>

          <form onSubmit={onSubmit} className="card-surface rounded-lg p-5 sm:p-8">
            <div className="grid gap-5 sm:grid-cols-2">
              <Input label="Name" name="name" value={formData.name} onChange={onChange} required />
              <Input label="Email" name="email" type="email" value={formData.email} onChange={onChange} required />
              <Input label="Age" name="age" type="number" value={formData.age} onChange={onChange} required />
              <Input label="Main stroke" name="mainStroke" value={formData.mainStroke} onChange={onChange} required />
              <Input label="Secondary stroke" name="secondaryStroke" value={formData.secondaryStroke} onChange={onChange} />
              <Input label="Main events" name="mainEvents" value={formData.mainEvents} onChange={onChange} required />
              <Textarea label="Current best times" name="bestTimes" value={formData.bestTimes} onChange={onChange} />
              <Select label="Course type" name="courseType" value={formData.courseType} onChange={onChange} options={['LCM', 'SCM', 'SCY']} />
              <Input label="Swim sessions per week" name="swimSessions" type="number" value={formData.swimSessions} onChange={onChange} required />
              <Input label="Gym experience" name="gymExperience" value={formData.gymExperience} onChange={onChange} required />
              <Textarea label="Equipment access" name="equipment" value={formData.equipment} onChange={onChange} required />
              <Textarea label="Goals" name="goals" value={formData.goals} onChange={onChange} required />
              <Textarea label="Weaknesses" name="weaknesses" value={formData.weaknesses} onChange={onChange} />
              <Textarea label="Injury history" name="injuryHistory" value={formData.injuryHistory} onChange={onChange} />
            </div>
            <button
              type="submit"
              className="mt-6 inline-flex min-h-12 w-full items-center justify-center rounded-md bg-forge-blue px-6 font-bold text-forge-black shadow-glow transition hover:bg-forge-cyan"
            >
              Submit Athlete Profile
              <Send className="ml-2" size={18} />
            </button>
            {submitted && (
              <div className="mt-5 rounded-lg border border-forge-blue/45 bg-forge-blue/10 p-4 text-forge-cyan">
                Your SwimForge profile has been submitted. Your program will be built and delivered
                within 24-48 hours.
              </div>
            )}
          </form>
        </div>
      </div>
    </section>
  )
}

function Input({ label, name, value, onChange, type = 'text', required = false }) {
  return (
    <label className="block">
      <span className="text-sm font-semibold text-slate-300">{label}</span>
      <input
        className="mt-2 min-h-12 w-full rounded-md border border-forge-line bg-forge-ink px-4 text-white outline-none transition placeholder:text-slate-500 focus:border-forge-cyan focus:ring-2 focus:ring-forge-blue/25"
        name={name}
        type={type}
        value={value}
        onChange={onChange}
        required={required}
      />
    </label>
  )
}

function Textarea({ label, name, value, onChange, required = false }) {
  return (
    <label className="block sm:col-span-2">
      <span className="text-sm font-semibold text-slate-300">{label}</span>
      <textarea
        className="mt-2 min-h-28 w-full resize-y rounded-md border border-forge-line bg-forge-ink px-4 py-3 text-white outline-none transition placeholder:text-slate-500 focus:border-forge-cyan focus:ring-2 focus:ring-forge-blue/25"
        name={name}
        value={value}
        onChange={onChange}
        required={required}
      />
    </label>
  )
}

function Select({ label, name, value, onChange, options }) {
  return (
    <label className="block">
      <span className="text-sm font-semibold text-slate-300">{label}</span>
      <span className="relative mt-2 block">
        <select
          className="min-h-12 w-full appearance-none rounded-md border border-forge-line bg-forge-ink px-4 pr-10 text-white outline-none transition focus:border-forge-cyan focus:ring-2 focus:ring-forge-blue/25"
          name={name}
          value={value}
          onChange={onChange}
        >
          {options.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
        </select>
        <ChevronDown className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
      </span>
    </label>
  )
}

function HowItWorks() {
  const steps = [
    'Choose your program',
    'Complete your athlete profile',
    'Your SwimForge system is built',
    'Receive your program within 24-48 hours',
  ]

  return (
    <section id="how-it-works" className="section-pad bg-forge-ink">
      <div className="container-shell">
        <div className="max-w-2xl">
          <p className="eyebrow">How It Works</p>
          <h2 className="mt-3 text-3xl font-black sm:text-4xl">Simple, focused, fast.</h2>
        </div>
        <div className="mt-10 grid gap-4 lg:grid-cols-4">
          {steps.map((step, index) => (
            <article key={step} className="card-surface rounded-lg p-6">
              <span className="grid h-11 w-11 place-items-center rounded-md bg-forge-blue text-lg font-black text-forge-black">
                {index + 1}
              </span>
              <h3 className="mt-5 text-xl font-bold leading-7">{step}</h3>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

function WhatYouGet() {
  return (
    <section id="benefits" className="section-pad bg-forge-black">
      <div className="container-shell">
        <div className="mx-auto max-w-2xl text-center">
          <p className="eyebrow">What You Get</p>
          <h2 className="mt-3 text-3xl font-black sm:text-4xl">Built for measurable race gains.</h2>
        </div>
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {benefits.map(([title, Icon]) => (
            <article key={title} className="card-surface rounded-lg p-6 transition hover:-translate-y-1 hover:border-forge-blue">
              <Icon className="text-forge-cyan" size={28} />
              <h3 className="mt-4 text-xl font-bold">{title}</h3>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

function ProgramStructure() {
  return (
    <section className="section-pad bg-forge-ink">
      <div className="container-shell">
        <div className="max-w-2xl">
          <p className="eyebrow">Program Structure</p>
          <h2 className="mt-3 text-3xl font-black sm:text-4xl">Four phases with a clear purpose.</h2>
        </div>
        <div className="mt-10 grid gap-5 md:grid-cols-2">
          {phases.map((phase, index) => (
            <article key={phase.name} className="grid grid-cols-[3.5rem_1fr] gap-5 rounded-lg border border-forge-line bg-forge-card p-5 sm:grid-cols-[4.5rem_1fr] sm:p-6">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-md border border-forge-blue/45 bg-forge-blue/12 text-xl font-black text-forge-cyan sm:h-16 sm:w-16">
                {String(index + 1).padStart(2, '0')}
              </div>
              <div className="min-w-0">
                <h3 className="text-2xl font-black">{phase.name}</h3>
                <p className="mt-2 leading-7 text-slate-300">{phase.text}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

function Faq() {
  const [openIndex, setOpenIndex] = useState(0)

  return (
    <section id="faq" className="section-pad bg-forge-black">
      <div className="container-shell">
        <div className="mx-auto max-w-3xl">
          <p className="eyebrow text-center">FAQ</p>
          <h2 className="mt-3 text-center text-3xl font-black sm:text-4xl">Common questions</h2>
          <div className="mt-10 space-y-3">
            {faqs.map(([question, answer], index) => {
              const isOpen = openIndex === index
              return (
                <div key={question} className="rounded-lg border border-forge-line bg-forge-card">
                  <button
                    type="button"
                    className="flex min-h-16 w-full items-center justify-between gap-4 px-5 text-left font-bold"
                    onClick={() => setOpenIndex(isOpen ? -1 : index)}
                  >
                    {question}
                    <ChevronDown className={`shrink-0 text-forge-cyan transition ${isOpen ? 'rotate-180' : ''}`} size={20} />
                  </button>
                  {isOpen && <p className="px-5 pb-5 leading-7 text-slate-300">{answer}</p>}
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}

function Footer() {
  return (
    <footer className="border-t border-white/10 bg-forge-ink py-10">
      <div className="container-shell grid gap-6 sm:grid-cols-[1fr_auto] sm:items-end">
        <div>
          <div className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-lg border border-forge-blue/45 bg-forge-blue/12 text-forge-cyan">
              <Waves size={22} />
            </span>
            <span className="text-xl font-black tracking-wide">SwimForge</span>
          </div>
          <p className="mt-3 text-slate-300">Build strength. Create speed.</p>
        </div>
        <div className="flex flex-col gap-2 text-sm font-semibold text-slate-300 sm:items-end">
          <span className="inline-flex items-center gap-2">
            <Instagram size={16} className="text-forge-cyan" /> Instagram: @swimforge
          </span>
          <span>TikTok: @swimforge</span>
          <span>Facebook: SwimForge</span>
        </div>
      </div>
    </footer>
  )
}

export default App
